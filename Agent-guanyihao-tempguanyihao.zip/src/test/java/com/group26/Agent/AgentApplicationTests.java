package com.group26.Agent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgentApplicationTests {

	@Test
	void contextLoads() {
	}

}
